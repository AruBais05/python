import pygame
from datetime import datetime
import math

RES = WIDTH, HEIGHT = 1200, 800
H_WIDTH, H_HEIGHT = WIDTH // 2, HEIGHT // 2
RADIUS = H_HEIGHT - 150  

pygame.init()
surface = pygame.display.set_mode(RES)
clock = pygame.time.Clock()
clock_img = pygame.image.load("clock1.jpg").convert_alpha()
mickey = pygame.image.load("mickey.png").convert_alpha()
mickey=pygame.transform.scale(mickey, (430,450))
clock_img=pygame.transform.scale(clock_img, (800,790))
clock60 = dict(zip(range(60), range(0, 360, 6)))

def get_clock_pos(clock_hand):
    angle = math.radians(clock60[clock_hand]) - math.pi / 2
    return H_WIDTH + RADIUS * math.cos(angle), H_HEIGHT + RADIUS * math.sin(angle)

while True:
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            exit()

    
    t = datetime.now()
    minute, second = t.minute, t.second
    surface.fill(pygame.Color('white'))
    surface.blit(clock_img, (200, 10))
    surface.blit(mickey, (380, 190))
    pygame.draw.line(surface, pygame.Color('black'), (H_WIDTH, H_HEIGHT), get_clock_pos(minute), 6)
    pygame.draw.line(surface, pygame.Color('red'), (H_WIDTH, H_HEIGHT), get_clock_pos(second), 4)
    pygame.draw.circle(surface, pygame.Color('black'), (H_WIDTH, H_HEIGHT), 8)

    pygame.display.flip()
    clock.tick(20)
